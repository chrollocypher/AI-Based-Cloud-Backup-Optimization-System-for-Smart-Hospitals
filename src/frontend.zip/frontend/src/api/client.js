// Thin client for the FastAPI backend (src/backend). Every route lives under /api/v1.
const BASE = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api/v1').replace(/\/+$/, '');

export const API_BASE = BASE;
// The interactive Swagger docs are served from the backend root, outside /api/v1.
export const DOCS_URL = BASE.replace(/\/api\/v1$/, '') + '/docs';

export class ApiError extends Error {
  constructor(message, status = 0) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

// FastAPI returns `detail` as a string for HTTPException and as a list for validation errors.
function detailToMessage(detail) {
  if (!detail) return null;
  if (typeof detail === 'string') return detail;
  if (Array.isArray(detail)) {
    return detail
      .map((d) => {
        const field = Array.isArray(d.loc) ? d.loc.filter((p) => p !== 'body').join('.') : '';
        return field ? `${field}: ${d.msg}` : d.msg;
      })
      .join('; ');
  }
  return JSON.stringify(detail);
}

async function request(path, { method = 'GET', body, params } = {}) {
  const qs = params
    ? new URLSearchParams(Object.entries(params).filter(([, v]) => v != null && v !== '')).toString()
    : '';
  const url = `${BASE}${path}${qs ? `?${qs}` : ''}`;

  let res;
  try {
    res = await fetch(url, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(
      `Can't reach the backend at ${BASE}. Check that the API is running and that VITE_API_BASE_URL is correct.`,
    );
  }

  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    /* non-JSON body */
  }
  if (!res.ok) throw new ApiError(detailToMessage(data?.detail) || `Request failed (${res.status})`, res.status);
  return data;
}

export const api = {
  // Health and monitoring
  health: () => request('/health'),
  monitoring: () => request('/monitoring/status'),

  // Dashboard
  summary: () => request('/dashboard/summary'),
  workload: () => request('/dashboard/workload'),

  // Records
  listRecords: () => request('/records'),
  getRecord: (id) => request(`/records/${encodeURIComponent(id)}`),
  createRecord: (record) => request('/records', { method: 'POST', body: record }),

  // Predictions
  latestPrediction: () => request('/predictions/latest'),
  predict: (input) => request('/predictions', { method: 'POST', body: input }),

  // Scheduler
  getSchedule: () => request('/schedule'),
  generateSchedule: () => request('/schedule', { method: 'POST' }),

  // Backups
  listBackups: (status) => request('/backups', { params: { status } }),
  getBackup: (id) => request(`/backups/${encodeURIComponent(id)}`),
  // With a record id: back up that record. Without: run every BACKUP_NOW item in the schedule.
  triggerBackup: (recordId) =>
    request('/backups', { method: 'POST', body: recordId ? { record_id: recordId } : undefined }),
  retryBackup: (id) => request(`/backups/${encodeURIComponent(id)}/retry`, { method: 'POST' }),
};

// The backend caches its last schedule, so regenerate it after anything that changes pending records.
export async function runBackups(recordId) {
  const jobs = await api.triggerBackup(recordId);
  await api.generateSchedule().catch(() => {});
  return jobs;
}
